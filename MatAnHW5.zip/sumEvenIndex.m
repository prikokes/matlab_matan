function g = sumEvenIndex(x)
    g = sum(x(1:2:end));
end