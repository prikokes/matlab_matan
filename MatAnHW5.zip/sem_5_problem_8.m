function g = sem_5_problem_8(x)
    x0 = x(1);
    y0 = x(2);
    g = sin(pi * x0) .* sin(pi * y0);
end
