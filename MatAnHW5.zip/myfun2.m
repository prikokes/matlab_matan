function g = myfun2(x)
    g = sin(x) - (x.^2).* cos(x);
end